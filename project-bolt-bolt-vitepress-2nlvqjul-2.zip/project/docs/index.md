---
layout: home

hero:
  name: Sistema de Facturación
  text: Gestión simple y eficiente de facturas
  tagline: Sistema completo para la gestión de facturas, clientes y productos
  actions:
    - theme: brand
      text: Comenzar
      link: /facturas
    - theme: alt
      text: Ver Clientes
      link: /clientes
---