import { defineConfig } from 'vite'

// Configuración de Vite
export default defineConfig({
  server: {
    hmr: {
      overlay: false // Deshabilita el overlay de errores HMR
    }
  }
})